import React from 'react';

const Index = () => {
    return (
        <div>
            booking flight
        </div>
    );
}

export default Index;
