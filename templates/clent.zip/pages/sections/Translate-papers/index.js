import React from 'react';

const Index = () => {
    return (
        <div>
            Translate papers
        </div>
    );
}

export default Index;
