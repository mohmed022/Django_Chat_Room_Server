import React from 'react';

const Index = () => {
    return (
        <div>
            money-transfer
        </div>
    );
}

export default Index;
