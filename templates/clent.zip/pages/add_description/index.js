import React from 'react';
import AddDescription from '../../components/Add/MainAdd/AddDescription';

const add_description = () => {
    return (
        <div>
            <AddDescription />
        </div>
    );
}

export default add_description;
