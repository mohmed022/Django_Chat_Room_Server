import React from 'react';

const Index = () => {
    return (
        <div>
            Scholarships
        </div>
    );
}

export default Index;
