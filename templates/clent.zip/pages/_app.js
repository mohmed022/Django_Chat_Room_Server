import Layout from "../components/Layout/Layout"
import "../styles/globals.css"
import "../styles/StyleAcc.css"
// import "../styles/input.css"
// import "../styles/index.css"

import "../styles/MyFromwork/background-color.css"
import "../styles/MyFromwork/border-radius.css"
import "../styles/MyFromwork/border.css"
import "../styles/MyFromwork/d-flex.css"
import "../styles/MyFromwork/font-size.css"
import "../styles/MyFromwork/height.css"
import "../styles/MyFromwork/lib_video.css"
import "../styles/MyFromwork/Loding.css"
import "../styles/MyFromwork/Rootfromwork.css"
import "../styles/MyFromwork/shadow.css"
import "../styles/MyFromwork/text.css"
import "../styles/MyFromwork/transform.css"
import "../styles/MyFromwork/width.css"
import "../styles/MyFromwork/Main.css"
import "../styles/MyFromwork/parent_ChatRoom.css"

import { Provider, useSelector } from 'react-redux'
import Store from '../components/Store/Store'
import "animate.css/animate.min.css";
import 'react-toastify/dist/ReactToastify.css';

import { useEffect, useState } from "react"
import jwt_decode from "jwt-decode";


function MyApp({ Component, pageProps }) {

  // const { UserLoginArry } = useSelector((state) => state.UserLoginArry);
  // const [user, setuser] = useState([]);
  const [auth, setAuth] = useState(false);
  
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [token, setToken] = useState(null);







// localStorage.removeitem('jwt')
  // useEffect(() => {
  //   const jwt = localStorage.getItem('jwt');
  //   if (jwt) {
  //   (async () => {
  //     try {
  //       const res = await fetch(userViewLoginNowLink, {
  //         method: "POST",
  //         headers: {
  //           "Content-Type": "application/json",
  //           'Authorization': `Bearer ${token}`
  //         },
  //         credentials: "include",
  //         body : JSON.stringify({
  //           jwt,
  //         }),
  //       });

  //       const content = await res.json();
  //       setuser(content);
  //       localStorage.setItem("content", JSON.stringify(content.email));
  //       if (content.detail==="Unauthenticated!"){
  //       setRefresh(false);
  //       }
  //       setAuth(true);
  //       // await content.first_name ?  notify(`login successful by user  ${content.first_name}`) : notifyerror(`You are not logged in`)
  //     } catch (e) {
  //       setuser("You are not logged in");
  //       // notifyerror(`You are not logged in`)
  //       setAuth(false);
  //     }
  //   })();}

  // }, []);


  // useEffect(() => {
  //   const storedToken = localStorage.getItem('jwt');
  //   if (storedToken) {
  //     setToken(storedToken);
  //     setIsLoggedIn(true);
  //   } else {
  //     setIsLoggedIn(false);
  //   }
  // }, []);

  // useEffect(() => {
  //   if (isLoggedIn) {
  //     const refreshToken = async () => {
  //       try {
  //         // Make a request to the server to refresh the token
  //         const response = await fetch('/api/refresh_token', {
  //           method: 'POST',
  //           headers: {
  //             'Content-Type': 'application/json',
  //             'Authorization': `Bearer ${token}`
  //           }
  //         });
  //         const data = await response.json();

  //         // Update the token in local storage
  //         localStorage.setItem('jwt', data.token);

  //         // Update the token in state
  //         setToken(data.token);
  //       } catch (error) {
  //         console.error(error);
  //       }
  //     };

  //     // Schedule the refresh token function to run every hour
  //     const intervalId = setInterval(refreshToken, 60 * 60 * 1000);

  //     // Clean up the interval when the component unmounts
  //     return () => clearInterval(intervalId);
  //   }
  // }, [isLoggedIn, token]);

// console.log(user)








  return (
    <Provider store={Store}>
      <Layout >
        {/* <ToastContainer/> */}
         <Component {...pageProps} />
      </Layout>
    </Provider>
  )
}

export default MyApp
