import React, { useEffect, useRef, useState } from 'react';
import { useRouter } from "next/router";
import ChooseingAStudySpecialty from '../../components/ViewUniversity/Main/ChooseingAStudySpecialty';
import { useDispatch, useSelector } from "react-redux";
import AddDescription from "../../components/Add/MainAdd/AddDescription";
import PhotoSection from '../../components/PhotoSection/PhotoSection';
import Head from 'next/head';
import Account from '../../components/Account/Account';
import { DeleteDescriptionUniversity } from '../../components/Store';
import { AnimationOnScroll } from 'react-animation-on-scroll';




const Index = ({auth}) => {
    const router = useRouter();
    const [id, setid] = useState(second)
    if (router) {
      const { id } = router.query;
      setid(id)
  }
    
    const {UserFulterArry} = useSelector((state) => state.UserFulterArry);

    const {UniversityArry , isLoadingUniversity , errorUniversity } = useSelector((state) => state.UniversityArry);
    const filteredUniversityArry = UniversityArry.filter((i) => i.id === Number(id))
    const item = filteredUniversityArry&&filteredUniversityArry[0]
    let itemId = item&&item.id
    let itemPhoto = item&&item.photo
    const {DescriptionUniversityArry , isLoadingDescriptionUniversity , errorDescriptionUniversity } = useSelector((state) => state.DescriptionUniversityArry);
    const {ListuniversityphotoArry , isLoadingListuniversityphoto , errorListuniversityphoto } = useSelector((state) => state.ListuniversityphotoArry);
    const filterDescriptionUniversityArry = DescriptionUniversityArry.filter((it)=> it.university === Number(itemId))
    const filterListuniversityphotoArry = ListuniversityphotoArry.filter((it)=> it.university === Number(itemId))
    const [showAddDesUn, setshowAddDesUn] = useState(false);
    const [showAddPhotoUn, setAddPhotoUn] = useState(false);
    const [ImgeNew, setImgeNew] = useState(item&&item.photo);
    const dispatch = useDispatch();

    return (
<>

    <Head>
      {/* <html dir="rtl" /> */}
      <title>view university {item&&item.name}</title>
      <meta name="next-head-count" content={React.Children.count(Head || []).toString()} />
      <meta property="og:title" dir="rtl" lang="ar" content="My page title" key="title" />
    </Head>

    <section id="" className="text-gray-600 w-100-100 body-font bg-w">
      <div className="container mx-auto p-rel mt-10 pt-10">  
        <video className="lg:w-full md:w-1/2 object-cover object-center rounded-lg md:mt-0 hei-vh-65 animate__bounceInUp" 
             controls src="/logo.mp4" id="my-video" width="620" height="390" poster="/assets/Russia.jpg" >
        </video>
        <div className="lg:w-full mx-auto">
        {/* <p className="text-3xl lg:text-5xl font-semibold text-gray-500 text-center m-8 ">{item&&item.name}</p> */}
          <div className="sm:w-full sm:pl-1 sm:py-8 sm:border-l sm:border-t-0 border-t mt-4 pt-4 sm:mt-0 text-center sm:text-left bbb-2 rad-20">
            <p className="fs-44  text-gray-500 bbb-1 text-right">{item&&item.name}</p>
            <p className="leading-relaxed text-lg text-right">{item&&item.description}</p>
            <br/>
            {UserFulterArry&&UserFulterArry.is_staff && <div onClick={()=>{setshowAddDesUn(!showAddDesUn)}} className="fa-solid fa-plus p-2 m-2 text-3xl text-orange-500"></div>}
            {showAddDesUn && <AddDescription IdUn={itemId} user={UserFulterArry&&UserFulterArry} auth={auth} />}
            <div className="flex flex-wrap  ">
            {filterDescriptionUniversityArry.map((i , index)=>
              <div key={index} className="bo-1 mb-8 rad-10 xl:w-1/4 lg:w-1/2 md:w-full px-4 py-6 border-l-2 border-gray-200 border-opacity-60">
                <AnimationOnScroll  animateIn='animate__bounceInUp'>
                <div className='d-flex align-c jus-b'>
                  <i onClick={()=>{dispatch(DeleteDescriptionUniversity(i.id))}} class="fa-solid fa-trash fs-22 "></i>
                  <h2 className="text-lg sm:text-xl font-medium title-font mb-2 col-bl text-center">{i.name}</h2>
                </div>
                </AnimationOnScroll>
                <AnimationOnScroll  animateIn='animate__bounceInUp'>
                <p className="leading-relaxed text-base mb-4 text-justify col-dis">{i.description}</p>
                </AnimationOnScroll>
              </div>)}
            </div>
          </div>
          
        </div>

      </div>


      <div className='lg:m-20 m-1'>
      
        <ChooseingAStudySpecialty item={item&&item} user={UserFulterArry&&UserFulterArry} auth={auth}/>
        <br/>
        <PhotoSection item={item&&item}/>
      </div>








</section>
</>
    );
}

export default Index;









