import React from 'react';

const Index = () => {
    return (
        <div>
            about-us
        </div>
    );
}

export default Index;
