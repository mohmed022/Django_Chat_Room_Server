import React from 'react';
import ViewUn from '../../components/ViewUniversity/ViewUniversity';

const Un = () => {
    return (
        <div className='mt-32'>
            <ViewUn/>
        </div>
    );
}

export default Un;
