import React, { useEffect, useState } from "react";
import Values from "../components/Values";
import ViewUn from "../components/ViewUniversity/ViewUniversity";
import Hero from "../components/HomeComponent/Hero";
import SubscriptionSteps from "../components/SubscriptionSteps";
import MoreInfoModal from "../components/MoreInfoModal";
import Head from "next/head";
import Student from "../components/Student/Student";
import Account from "../components/Account/Account";
import { useSelector } from "react-redux";
import ChatAssist from "../components/Add/handellPup/page3/chatAssist";
import Link from "next/link";








const Index = ({ auth }) => {
  const {UserFulterArry} = useSelector((state) => state.UserFulterArry);
  const [error, setError] = useState(null); // Error state
  const [Active, setActive] = useState(null); // Error state
  const Arry = [
     {id:1 , name : "hero" },
     {id:2 , name : "Values" },
     {id:3 , name : "SubscriptionSteps" },
     {id:4 , name : "ViewUn" },
     {id:5 , name : "Student" },
     {id:6 , name : "MoreInfoModal" },
     {id:7 , name : "footer" },
    ]

  const handleButtonClick = (id) => {
    const element = document.getElementById(id);
    element.scrollIntoView({ behavior: "smooth" }); // scroll to the element with a smooth effect
  };

  const ArryCircle = Arry.map((circle)=> {
    return(
    <div className={`circle w-3 h-3 ${Active === circle.id && " w-5 h-5 bb-1 bg-or" }`}  onClick={() => { handleButtonClick(circle.name);setActive(circle.id) }} ></div>
    )
  })

  return (
    <>
      <Head>
        <title>Home</title>
        <meta property="og:title" dir="rtl" lang="ar" content="My page title" key="title" />
      </Head>
      <div className="div-hero min-h-screen" style={{ backgroundImage: `url("./homebg.jpg")`, backgroundSize: 'cover', backgroundPosition: 'center', width: "100%" }}>
      <div className="circles block" style={{zIndex:"51"}}>{ArryCircle}</div> 
        <Hero />
        <Values />
        <SubscriptionSteps />
        <ViewUn type={UserFulterArry && UserFulterArry.is_staff} user={UserFulterArry && UserFulterArry} auth={auth} />
        <Student />
        <MoreInfoModal />
      </div>
    </>
  );
};

export default Index;























// const Index = ({ auth}) => {
//   const {UserFulterArry} = useSelector((state) => state.UserFulterArry);
//   const handleButtonClick = (e) => {
//     window.scrollTo(e, window.innerHeight);
//   };
//   return (
//     <>
//       <Head>
//          {/* <html dir="rtl" /> */}
//          <title>Home</title>
//          <meta property="og:title" dir="rtl" lang="ar" content="My page title" key="title" />
//       </Head>
//       <div className='div-hero min-h-screen '  style={{ backgroundImage: `url("./homebg.jpg")`, backgroundSize: 'cover', backgroundPosition: 'center', width: "100%" }}>
//          <div class="circles block">
//            <div onClick={()=>{handleButtonClick(100)}} class="circle"></div>
//            <div onClick={()=>{handleButtonClick(200)}} class="circle"></div>
//            <div onClick={()=>{handleButtonClick(300)}} class="circle"></div>
//            <div onClick={()=>{handleButtonClick(400)}} class="circle"></div>
//            <div onClick={()=>{handleButtonClick(500)}} class="circle"></div>
//          </div>
//          <Hero />
//          <Values/>
//          <SubscriptionSteps />
//          <ViewUn type={UserFulterArry&&UserFulterArry.is_staff} user={UserFulterArry&&UserFulterArry} auth={auth}/>
//          <Student />
//          <MoreInfoModal/>
//     </div> 
//     </>
//   );
// };

// export default Index;
